# Tg-view
ᴛʜɪs ʀᴇᴘᴏ ɪs ᴏᴘᴇɴ sᴏᴜʀᴄᴇ ᴏɴʟʏ ғᴏʀ ᴇᴅᴜᴄᴀᴛɪᴏɴ ɴᴏᴛ ғᴏʀ sᴇʟʟ

<h2 align="center">
    ──「 Tg-views Tools 」──
</h2>

<p align="center">
  <img src="https://graph.org/file/ee246c62744784b0e44df.jpg">
</p>
# Features Of Tg-views TOOLS ❤️

<details>
<summary><b>Install all cmds :</b></summary><br>

     apt update && apt upgrade && pkg install python && pkg install git && git clone https://github.com/shivay-xd/Tg-view
     cd Tg-view
     ls
     pip install -r requirements.txt
     python view.py
</details>
